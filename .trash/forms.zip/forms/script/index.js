function fecharModal() {
  document.getElementById('modal').style.display = 'none';
  document.getElementById('form-container').classList.remove('hidden');
}

